<?php
include_once('./connection_bd.php');
header('Content-type: text/plain');
header('Content-Disposition: attachment; filename="database_skydivelogbook.dump"');

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM AVION;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO AVION (ID,LIBELLE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM DROPZONE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO DROPZONE (ID,LIBELLE) VALUES (".$enregistrement->id.",'".str_replace("'","''",$enregistrement->libelle)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,HAUTEUR FROM HAUTEUR;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO HAUTEUR (ID,HAUTEUR) VALUES (".$enregistrement->id.",".$enregistrement->hauteur.");\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE,SURFACE FROM MATERIEL;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO MATERIEL (ID,LIBELLE,SURFACE) VALUES (".$enregistrement->id.",'".str_replace("'","''",$enregistrement->libelle)."',".$enregistrement->surface.");\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM TYPESAUT;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO TYPESAUT (ID,LIBELLE) VALUES (".$enregistrement->id.",'".str_replace("'","''",$enregistrement->libelle)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM WINDTUNNEL;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO WINDTUNNEL (ID,LIBELLE) VALUES (".$enregistrement->id.",'".str_replace("'","''",$enregistrement->libelle)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT id,DATE_FORMAT(DATE,'%Y/%m/%d') AS DATE,TEMPS,WINDTUNNELID,COMMENTAIRES FROM SOUFFLETTE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO SOUFFLETTE (ID,DATE,TEMPS,WINDTUNNELID,COMMENTAIRES) VALUES (".$enregistrement->id.",'".$enregistrement->date."',".$enregistrement->temps.",".$enregistrement->windtunnelid.",'".str_replace("'","''",$enregistrement->commentaires)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,DATE_FORMAT(DATE,'%Y/%m/%d') AS DATE,DROPZONEID,HAUTEURID,AVIONID,MATERIELID,TYPESAUTID,COMMENTAIRES FROM JUMP;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO JUMP (ID,DATE,DROPZONEID,HAUTEURID,AVIONID,MATERIELID,TYPESAUTID,COMMENTAIRES) VALUES (".$enregistrement->id.",'".$enregistrement->date."',".$enregistrement->dropzoneid.",".$enregistrement->hauteurid.",".$enregistrement->avionid.",".$enregistrement->materielid.",".$enregistrement->typesautid.",'".str_replace("'","''",$enregistrement->commentaires)."');\n";
}


?>