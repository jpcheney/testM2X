<?php
include_once('./connection_bd.php');
header('Content-type: text/plain');
header('Content-Disposition: attachment; filename="database_skydivelogbook.dump"');

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM AVION;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO AVION (ID,LIBELLE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM DROPZONE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO DROPZONE (ID,LIBELLE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,HAUTEUR FROM HAUTEUR;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO HAUTEUR (ID,HAUTEUR) VALUES (".$enregistrement->ID.",".$enregistrement->HAUTEUR.");\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE,SURFACE FROM MATERIEL;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO MATERIEL (ID,LIBELLE,SURFACE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."',".$enregistrement->surface.");\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM TYPESAUT;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO TYPESAUT (ID,LIBELLE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,LIBELLE FROM WINDTUNNEL;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO WINDTUNNEL (ID,LIBELLE) VALUES (".$enregistrement->ID.",'".str_replace("'","''",$enregistrement->LIBELLE)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT id,DATE_FORMAT(DATE,'%Y/%m/%d') AS DATE,TEMPS,WINDTUNNELID,COMMENTAIRES FROM SOUFFLETTE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO SOUFFLETTE (ID,DATE,TEMPS,WINDTUNNELID,COMMENTAIRES) VALUES (".$enregistrement->ID.",'".$enregistrement->DATE."',".$enregistrement->TEMPS.",".$enregistrement->WINDTUNNELID.",'".str_replace("'","''",$enregistrement->COMMENTAIRES)."');\n";
}

$selectionPrepa = $connection->prepare("SELECT ID,DATE_FORMAT(DATE,'%Y/%m/%d') AS DATE,DROPZONEID,HAUTEURID,AVIONID,MATERIELID,TYPESAUTID,COMMENTAIRES FROM JUMP;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
while($enregistrement = $selectionPrepa->fetch()){
	echo "INSERT INTO JUMP (ID,DATE,DROPZONEID,HAUTEURID,AVIONID,MATERIELID,TYPESAUTID,COMMENTAIRES) VALUES (".$enregistrement->ID.",'".$enregistrement->DATE."',".$enregistrement->DROPZONEID.",".$enregistrement->HAUTEURID.",".$enregistrement->AVIONID.",".$enregistrement->MATERIELID.",".$enregistrement->TYPESAUTID.",'".str_replace("'","''",$enregistrement->COMMENTAIRES)."');\n";
}


?>