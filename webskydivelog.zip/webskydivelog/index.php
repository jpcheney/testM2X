<?php
	include_once('./connection_bd.php');
?>
<html>
	<head>
		<title>Web Carnet de sauts</title>
		<LINK REL="stylesheet" TYPE="text/css" HREF="https://www.jpcheney.org/style.php">
		<LINK REL="stylesheet" TYPE="text/css" HREF="https://www.jpcheney.org/style.css">
	</head>
	<body style="width:100%;">
		<div id="content" style="text-align:center;">
			<h1>Skydive Log</h1>
			
			<h2>Liste des sauts</h2>
			<table style="margin: 0 auto;">
				<tr>
					<th>Numero</th>
					<th>Date</th>
					<th>Zone de saut</th>
					<th>Hauteur</th>
					<th>Type de saut</th>
					<th>Avion</th>
					<th>Parachute</th>
					<th>Commentaires</th>
				</tr>
<?php
$selectionPrepa = $connection->prepare("SELECT DATE_FORMAT(JUMP.DATE,'%d/%m/%Y') AS date_saut,DROPZONE.LIBELLE AS libelle_dropzone,".
	" HAUTEUR.HAUTEUR AS libelle_hauteur,AVION.LIBELLE AS libelle_avion,MATERIEL.LIBELLE AS libelle_materiel,".
	" MATERIEL.SURFACE AS surface_materiel,TYPESAUT.LIBELLE AS libelle_typesaut,JUMP.COMMENTAIRES AS commentaires".
	" FROM JUMP,DROPZONE,HAUTEUR,AVION,MATERIEL,TYPESAUT".
	" WHERE DROPZONE.ID=JUMP.DROPZONEID".
	" AND HAUTEUR.ID=JUMP.HAUTEURID".
	" AND AVION.ID=JUMP.AVIONID".
	" AND MATERIEL.ID=JUMP.MATERIELID".
	" AND TYPESAUT.ID=JUMP.TYPESAUTID".
	" order by JUMP.DATE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
$compteur=1;
$no_ligne=1;
$class_td = "paire";

while($enregistrement = $selectionPrepa->fetch()){
	if($compteur==1){
		$class_td = "paire";
	}else{
		$class_td = "impaire";
	}
?>
				<tr class="<?php echo $class_td;?>">
					<td style="text-align:right;"><?php echo $no_ligne;?></td>
					<td><?php echo $enregistrement->date_saut;?></td>
					<td><?php echo $enregistrement->libelle_dropzone;?></td>
					<td style="text-align:right;"><?php echo $enregistrement->libelle_hauteur;?></td>
					<td><?php echo $enregistrement->libelle_avion;?></td>
					<td><?php echo $enregistrement->libelle_materiel;?> <?php echo $enregistrement->surface_materiel;?></td>
					<td><?php echo $enregistrement->libelle_typesaut;?></td>
					<td><?php echo $enregistrement->commentaires;?></td>
				</tr>
<?php
	$no_ligne = $no_ligne + 1;
	$compteur  = - $compteur; 
}
?>
			</table>
			
			<h2>Liste des sceances de souflette</h2>
			<table style="margin: 0 auto;">
				<tr>
					<th>Numero</th>
					<th>Date</th>
					<th>Souflette</th>
					<th>Temps (mn)</th>
					<th>Commentaires</th>
				</tr>
			
<?php
$selectionPrepa = $connection->prepare("SELECT DATE_FORMAT(SOUFFLETTE.DATE,'%d/%m/%Y') AS date_soufflette,WINDTUNNEL.LIBELLE AS libelle_windtunnel,".
	" SOUFFLETTE.TEMPS AS temps_souflette,SOUFFLETTE.COMMENTAIRES AS commentaires".
	" FROM SOUFFLETTE,WINDTUNNEL".
	" WHERE WINDTUNNEL.ID=SOUFFLETTE.WINDTUNNELID".
	" order by SOUFFLETTE.DATE;");
$selectionPrepa->execute();
$selectionPrepa->setFetchMode(PDO::FETCH_OBJ);
$compteur=1;
$no_ligne=1;
$class_td = "paire";

while($enregistrement = $selectionPrepa->fetch()){
	if($compteur==1){
		$class_td = "paire";
	}else{
		$class_td = "impaire";
	}
?>
				<tr class="<?php echo $class_td;?>">
					<td style="text-align:right;"><?php echo $no_ligne;?></td>
					<td><?php echo $enregistrement->date_soufflette;?></td>
					<td><?php echo $enregistrement->libelle_windtunnel;?></td>
					<td><?php echo $enregistrement->temps_souflette;?></td>
					<td><?php echo $enregistrement->commentaires;?></td>
				</tr>
<?php
	$no_ligne = $no_ligne + 1;
	$compteur  = - $compteur; 
}
?>
			</table>
			
			<h2>Envoi du fichier de sauvegarde</h2>
			<form name="formulaire" action="insertData.php" method="POST" enctype="multipart/form-data">
				<input type="file" name="fichier_dump">
				<input type="submit" value="Envoyer">
			</form>
			
			<a href="exportData.php"><h2>Export du fichier de sauvegarde</h2></a>
		</div>
	</body>
</html>