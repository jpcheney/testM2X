<?php
// Connection au serveur
try {
	$dns = 'mysql:host=localhost;dbname=webskydivelog';
	$user = 'webskydivelogUSE';
	$passwd = 'webskydivelogPAS';
	$connection = new PDO( $dns, $user, $passwd );
	$connection->exec('SET NAMES utf8');
}catch ( Exception $e ) {
  echo "Connection � MySQL impossible : ", $e->getMessage();
  die();
}

?>
