<?php
if ($_FILES['fichier_dump']['error']) {     
	switch ($_FILES['fichier_dump']['error']){     
		case 1: // UPLOAD_ERR_INI_SIZE     
		echo"Le fichier d�passe la limite autoris�e par le serveur (fichier php.ini) !";     
		break;     
		case 2: // UPLOAD_ERR_FORM_SIZE     
		echo "Le fichier d�passe la limite autoris�e dans le formulaire HTML !"; 
		break;     
		case 3: // UPLOAD_ERR_PARTIAL     
		echo "L'envoi du fichier a �t� interrompu pendant le transfert !";     
		break;     
		case 4: // UPLOAD_ERR_NO_FILE     
		echo "Le fichier que vous avez envoy� a une taille nulle !"; 
		break;     
	}     
}else{
	set_time_limit(3600);
	include_once('./connection_bd.php');
	$selectionPrepa = $connection->prepare("DELETE FROM AVION;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM DROPZONE;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM MATERIEL;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM TYPESAUT;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM WINDTUNNEL;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM SOUFFLETTE;");
	$selectionPrepa->execute();
	$selectionPrepa = $connection->prepare("DELETE FROM JUMP;");
	$selectionPrepa->execute();
		
	$fp = fopen($_FILES['fichier_dump']['tmp_name'],"r");
	$ligne_en_cours = "";
	$nb_lignes=0;
	while (!feof($fp)) {
		$ligne = fgets($fp);
		$selectionPrepa = $connection->prepare($ligne);
		$selectionPrepa->execute();
	}
	fclose($fp);
} 

header("Location: index.php");
?>